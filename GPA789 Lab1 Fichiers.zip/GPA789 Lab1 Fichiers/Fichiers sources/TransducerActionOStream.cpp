#include "TransducerActionOStream.h"


TransducerActionOStream::TransducerActionOStream(ostream * oStream)
	: mOStream{ oStream }
{
}

